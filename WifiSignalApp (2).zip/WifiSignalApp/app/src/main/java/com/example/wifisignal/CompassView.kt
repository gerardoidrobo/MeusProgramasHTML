package com.example.wifisignal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Bússola de sinal: o usuário gira o celular e o app guarda a força do sinal
 * (dBm) para cada direção (36 setores de 10 graus). A seta aponta para a
 * direção real onde o sinal foi mais forte, e continua apontando para lá
 * mesmo quando o celular gira.
 */
class CompassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val binCount = 36
    private val binSize = 360f / binCount
    private val bins = FloatArray(binCount) { Float.NaN }
    private var heading = 0f

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#44888888")
        strokeWidth = 2f
    }

    private val wedgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE
        color = Color.parseColor("#2196F3")
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
    }

    private val frontPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#888888")
        strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#888888")
        textSize = 34f
        textAlign = Paint.Align.CENTER
    }

    private val northPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E53935")
        textSize = 38f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }

    private val rect = RectF()
    private val headPath = Path()

    fun setHeading(degrees: Float) {
        heading = degrees
        invalidate()
    }

    fun addSample(bearingDeg: Float, rssi: Int) {
        val b = ((bearingDeg % 360f) + 360f) % 360f
        val i = (b / binSize).toInt().coerceIn(0, binCount - 1)
        val old = bins[i]
        bins[i] = if (old.isNaN()) rssi.toFloat() else old * 0.5f + rssi * 0.5f
        invalidate()
    }

    fun reset() {
        for (i in 0 until binCount) bins[i] = Float.NaN
        invalidate()
    }

    /** Direção (0 a 360, a partir do norte) do setor com maior sinal, ou null. */
    fun bestBearing(): Float? {
        var bestIdx = -1
        var bestVal = Float.NEGATIVE_INFINITY
        for (i in 0 until binCount) {
            val v = bins[i]
            if (!v.isNaN() && v > bestVal) {
                bestVal = v
                bestIdx = i
            }
        }
        return if (bestIdx < 0) null else bestIdx * binSize + binSize / 2f
    }

    /** Fração dos 36 setores já medidos, de 0.0 a 1.0. */
    fun coverage(): Float = bins.count { !it.isNaN() } / binCount.toFloat()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f - 40f
        if (r <= 0f) return

        canvas.drawCircle(cx, cy, r, ringPaint)
        canvas.drawCircle(cx, cy, r * 0.66f, ringPaint)
        canvas.drawCircle(cx, cy, r * 0.33f, ringPaint)

        for (i in 0 until binCount) {
            val v = bins[i]
            if (v.isNaN()) continue
            val norm = ((v + 100f) / 70f).coerceIn(0f, 1f)
            val rr = r * (0.2f + 0.8f * norm)
            wedgePaint.color = Color.HSVToColor(210, floatArrayOf(norm * 120f, 0.85f, 0.9f))
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            val start = i * binSize - heading - 90f
            canvas.drawArc(rect, start, binSize, true, wedgePaint)
        }

        val labels = arrayOf("N", "L", "S", "O")
        for (k in 0..3) {
            val a = Math.toRadians((k * 90f - heading).toDouble())
            val tx = cx + (r + 24f) * sin(a).toFloat()
            val ty = cy - (r + 24f) * cos(a).toFloat() + 12f
            canvas.drawText(labels[k], tx, ty, if (k == 0) northPaint else textPaint)
        }

        val best = bestBearing()
        if (best != null) {
            val a = Math.toRadians((best - heading).toDouble())
            val dx = sin(a).toFloat()
            val dy = -cos(a).toFloat()
            val ex = cx + dx * r * 0.95f
            val ey = cy + dy * r * 0.95f
            canvas.drawLine(cx, cy, ex, ey, arrowPaint)

            val head = 34f
            val px = -dy
            val py = dx
            headPath.reset()
            headPath.moveTo(ex + dx * 12f, ey + dy * 12f)
            headPath.lineTo(ex - dx * head + px * head * 0.6f, ey - dy * head + py * head * 0.6f)
            headPath.lineTo(ex - dx * head - px * head * 0.6f, ey - dy * head - py * head * 0.6f)
            headPath.close()
            canvas.drawPath(headPath, arrowPaint)
        }

        canvas.drawLine(cx, cy - r - 12f, cx, cy - r + 14f, frontPaint)
        canvas.drawCircle(cx, cy, 8f, frontPaint)
    }
}
