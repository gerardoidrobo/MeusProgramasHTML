
## Novidades (versão 2)

- **Tempo real**: para a rede à qual o celular está conectado, o app lê o sinal ao vivo. Para outras redes usa a varredura do Android.
- **Wi-Fi desligado ou rede fora do ar**: o app para de apitar e avisa na tela (antes ele repetia a última lista guardada pelo Android).
- **Distância estimada**: calculada pelo sinal (modelo de perda de percurso, expoente 3). É uma estimativa grosseira: paredes, móveis e o corpo mudam o resultado.
- **Bússola de sinal**: gire o celular na horizontal; o app guarda o sinal de cada direção (setores de 10 graus) e a seta aponta para onde foi mais forte.
- **Aviso**: ao instalar por cima de uma versão anterior, o Android pode recusar (assinatura diferente). Desinstale a antiga antes.
