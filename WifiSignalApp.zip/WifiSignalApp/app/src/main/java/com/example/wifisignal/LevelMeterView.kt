package com.example.wifisignal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Coluna de força do sinal, no estilo dos medidores de volume de um som:
 * 20 segmentos que sobem e descem com suavização, com marca de pico.
 * Vermelho = sinal fraco, verde = sinal forte.
 */
class LevelMeterView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val segs = 20
    private var target = 0f
    private var level = 0f
    private var peak = 0
    private var peakHold = 0

    private val segPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#888888")
        textSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 11f, resources.displayMetrics
        )
    }
    private val rect = RectF()

    private val ticker = object : Runnable {
        override fun run() {
            step()
            invalidate()
            postDelayed(this, 50L)
        }
    }

    fun setRssi(rssi: Int) {
        target = ((rssi + 100f) / 70f * segs).coerceIn(0f, segs.toFloat())
    }

    fun setIdle() {
        target = 0f
    }

    private fun step() {
        level += (target - level) * 0.35f
        val n = level.roundToInt()
        if (n >= peak) {
            peak = n
            peakHold = 8
        } else if (peakHold > 0) {
            peakHold--
        } else if (peak > 0) {
            peak--
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val labelW = textPaint.measureText("-100") + 6f
        val barW = max(10f, w - labelW)
        val gap = 3f * resources.displayMetrics.density / 2f
        val segH = (h - gap * (segs - 1)) / segs
        val n = level.roundToInt()

        for (q in 0 until segs) {
            val bottom = h - q * (segH + gap)
            val top = bottom - segH
            rect.set(0f, top, barW, bottom)
            val hue = q / (segs - 1f) * 130f
            val color = Color.HSVToColor(floatArrayOf(hue, 0.78f, 0.85f))
            when {
                q < n -> {
                    segPaint.color = color
                    segPaint.alpha = 255
                }
                q == peak - 1 -> {
                    segPaint.color = color
                    segPaint.alpha = 140
                }
                else -> {
                    segPaint.color = Color.parseColor("#33888888")
                    segPaint.alpha = 255
                }
            }
            canvas.drawRoundRect(rect, 3f, 3f, segPaint)
        }

        val x = barW + 6f
        canvas.drawText("-30", x, textPaint.textSize, textPaint)
        canvas.drawText("-65", x, h / 2f + textPaint.textSize / 3f, textPaint)
        canvas.drawText("-100", x, h, textPaint)
    }
}
