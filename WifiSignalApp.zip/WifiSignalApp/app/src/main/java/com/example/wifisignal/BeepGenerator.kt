package com.example.wifisignal

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Gera um "beep" cujo tom (frequência) varia de acordo com a força do
 * sinal Wi-Fi (RSSI, em dBm). Sinal forte = tom agudo. Sinal fraco = tom grave.
 */
class BeepGenerator {

    private val sampleRate = 44100
    private val mainHandler = Handler(Looper.getMainLooper())

    fun beepForRssi(rssi: Int) {
        // RSSI típico varia de -30 dBm (excelente) a -100 dBm (péssimo/sem sinal)
        val clamped = max(-100, min(-30, rssi))
        val ratio = (clamped + 100) / 70.0 // 0.0 (fraco) até 1.0 (forte)
        val frequency = 300.0 + (ratio * 1700.0) // 300 Hz a 2000 Hz
        playTone(frequency, durationMs = 120)
    }

    private fun playTone(freqHz: Double, durationMs: Int) {
        val numSamples = durationMs * sampleRate / 1000
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val angle = 2.0 * PI * i * freqHz / sampleRate
            buffer[i] = (sin(angle) * Short.MAX_VALUE * 0.6).toInt().toShort()
        }

        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(buffer.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        audioTrack.write(buffer, 0, buffer.size)
        audioTrack.play()

        mainHandler.postDelayed({
            try {
                audioTrack.release()
            } catch (_: Exception) {
            }
        }, durationMs.toLong() + 50)
    }
}
