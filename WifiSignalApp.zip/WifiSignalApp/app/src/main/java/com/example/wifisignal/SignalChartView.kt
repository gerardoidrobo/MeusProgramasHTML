package com.example.wifisignal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Gráfico simples de linha mostrando o histórico recente da força do sinal (dBm).
 * Não usa nenhuma biblioteca externa — só Canvas nativo do Android.
 */
class SignalChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val historico = ArrayDeque<Int>()
    private val maxPontos = 60 // quantidade de leituras mantidas no gráfico

    private val minDbm = -100
    private val maxDbm = -30

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2196F3")
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#332196F3")
        style = Paint.Style.FILL
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33888888")
        strokeWidth = 2f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#888888")
        textSize = 26f
    }

    fun addValue(rssi: Int) {
        historico.addLast(rssi)
        while (historico.size > maxPontos) {
            historico.removeFirst()
        }
        invalidate()
    }

    fun limpar() {
        historico.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        val paddingLeft = 70f
        val paddingBottom = 10f
        val paddingTop = 10f
        val chartW = w - paddingLeft
        val chartH = h - paddingBottom - paddingTop

        // Linhas de grade horizontais com o valor em dBm
        var dbm = maxDbm
        while (dbm >= minDbm) {
            val y = paddingTop + chartH * (maxDbm - dbm).toFloat() / (maxDbm - minDbm).toFloat()
            canvas.drawLine(paddingLeft, y, w, y, gridPaint)
            canvas.drawText("$dbm", 4f, y + 8f, textPaint)
            dbm -= 20
        }

        if (historico.size < 2) return

        val n = historico.size
        val pontosX = FloatArray(n)
        val pontosY = FloatArray(n)
        historico.forEachIndexed { i, valor ->
            val clamped = max(minDbm, min(maxDbm, valor))
            val x = paddingLeft + chartW * i.toFloat() / (maxPontos - 1).toFloat()
            val y = paddingTop + chartH * (maxDbm - clamped).toFloat() / (maxDbm - minDbm).toFloat()
            pontosX[i] = x
            pontosY[i] = y
        }

        // Área preenchida abaixo da linha
        val path = Path()
        path.moveTo(pontosX[0], paddingTop + chartH)
        for (i in 0 until n) {
            path.lineTo(pontosX[i], pontosY[i])
        }
        path.lineTo(pontosX[n - 1], paddingTop + chartH)
        path.close()
        canvas.drawPath(path, fillPaint)

        // Linha do gráfico
        for (i in 0 until n - 1) {
            canvas.drawLine(pontosX[i], pontosY[i], pontosX[i + 1], pontosY[i + 1], linePaint)
        }
    }
}
