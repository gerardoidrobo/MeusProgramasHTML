package com.example.wifisignal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Diagrama de radiação em gráfico polar (visto de cima).
 *
 * O roteador fica no centro. O usuário anda ao redor dele, sempre de frente para o
 * roteador e com o celular na horizontal, a uma distância fixa. O ângulo de cada
 * amostra é a posição da pessoa em relação ao roteador. Para cada setor de 10 graus
 * guardamos a média da potência (em mW, não em dB) de todas as leituras, de modo
 * que várias voltas melhoram a média. O gráfico mostra o resultado em dB relativo
 * ao máximo (0 dB na borda). Um avatar anda na órbita ao redor do roteador.
 */
class RadiationView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val binCount = 36
    private val binSize = 10f
    private val sumP = DoubleArray(binCount)
    private val cnt = IntArray(binCount)
    private var heading = 0f

    var sampleCount = 0
        private set

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#66888888")
        strokeWidth = 1f
    }
    private val spokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#33888888")
        strokeWidth = 1f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#888888")
        textSize = 13f
        textAlign = Paint.Align.CENTER
    }
    private val smallTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#888888")
        textSize = 11f
        textAlign = Paint.Align.LEFT
    }
    private val northPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E53935")
        textSize = 13f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#552196F3")
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#2196F3")
        strokeWidth = 2f
        strokeJoin = Paint.Join.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#2196F3")
    }
    private val bestPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#43A047")
        strokeWidth = 2f
    }
    private val headingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#FB8C00")
        strokeWidth = 1.8f
        strokeCap = Paint.Cap.ROUND
        pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f)
    }
    private val armPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#1D9E75")
        strokeWidth = 2.6f
        strokeCap = Paint.Cap.ROUND
    }
    private val phoneFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#85B7EB")
    }
    private val phoneStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#185FA5")
        strokeWidth = 0.8f
    }
    private val bodyFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#5DCAA5")
    }
    private val bodyStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#0F6E56")
        strokeWidth = 0.8f
    }
    private val headFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#D3D1C7")
    }
    private val headStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#5F5E5A")
        strokeWidth = 0.8f
    }
    private val nosePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#5F5E5A")
    }
    private val routerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FAEEDA")
    }
    private val routerStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#BA7517")
        strokeWidth = 1.4f
        strokeCap = Paint.Cap.ROUND
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#EF9F27")
        strokeWidth = 1.8f
        strokeCap = Paint.Cap.ROUND
    }

    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#55888888")
        strokeWidth = 1f
        pathEffect = DashPathEffect(floatArrayOf(3f, 4f), 0f)
    }

    private val path = Path()
    private val nosePath = Path()
    private val rect = RectF()

    fun setHeading(degrees: Float) {
        heading = degrees
        invalidate()
    }

    fun addSample(bearingDeg: Float, rssi: Int) {
        val b = ((bearingDeg % 360f) + 360f) % 360f
        val i = (b / binSize).toInt().coerceIn(0, binCount - 1)
        sumP[i] += 10.0.pow(rssi / 10.0)
        cnt[i]++
        sampleCount++
        invalidate()
    }

    fun reset() {
        for (i in 0 until binCount) {
            sumP[i] = 0.0
            cnt[i] = 0
        }
        sampleCount = 0
        invalidate()
    }

    private fun averages(): DoubleArray {
        val avg = DoubleArray(binCount) { Double.NaN }
        for (k in 0 until binCount) {
            if (cnt[k] > 0) avg[k] = 10.0 * log10(sumP[k] / cnt[k])
        }
        return avg
    }

    private fun maxValue(avg: DoubleArray): Double {
        var mx = Double.NEGATIVE_INFINITY
        for (v in avg) if (!v.isNaN() && v > mx) mx = v
        return mx
    }

    private fun bestIndex(avg: DoubleArray): Int {
        var bi = -1
        var mx = Double.NEGATIVE_INFINITY
        for (k in 0 until binCount) {
            if (!avg[k].isNaN() && avg[k] > mx) {
                mx = avg[k]
                bi = k
            }
        }
        return bi
    }

    /** Direção (0 a 360, a partir do norte) do setor com maior sinal, ou null. */
    fun bestBearing(): Float? {
        val bi = bestIndex(averages())
        return if (bi < 0) null else bi * binSize + binSize / 2f
    }

    /** Largura angular, em graus, onde o sinal fica a até 3 dB do máximo. */
    fun beamwidthDeg(): Int {
        val avg = averages()
        val bi = bestIndex(avg)
        if (bi < 0) return 0
        val mx = avg[bi]
        var c = 1
        var k = (bi + binCount - 1) % binCount
        var g = 0
        while (g < binCount && !avg[k].isNaN() && avg[k] - mx >= -3.0) {
            c++
            k = (k + binCount - 1) % binCount
            g++
        }
        k = (bi + 1) % binCount
        g = 0
        while (g < binCount && !avg[k].isNaN() && avg[k] - mx >= -3.0) {
            c++
            k = (k + 1) % binCount
            g++
        }
        return min(360, (c * binSize).toInt())
    }

    /** Fração dos 36 setores já medidos, de 0.0 a 1.0. */
    fun coverage(): Float = cnt.count { it > 0 } / binCount.toFloat()

    fun toCsv(ssid: String): String {
        val avg = averages()
        val mx = maxValue(avg)
        val sb = StringBuilder()
        sb.append("# rede: ").append(ssid).append('\n')
        sb.append("angulo_graus,potencia_media_dbm,relativo_ao_maximo_db,amostras\n")
        for (k in 0 until binCount) {
            if (cnt[k] == 0) continue
            sb.append(
                String.format(
                    Locale.US, "%.0f,%.1f,%.1f,%d\n",
                    k * binSize + binSize / 2f, avg[k], avg[k] - mx, cnt[k]
                )
            )
        }
        return sb.toString()
    }

    private fun px(r: Float, bearing: Float): Float =
        r * sin(Math.toRadians(bearing.toDouble())).toFloat()

    private fun py(r: Float, bearing: Float): Float =
        -r * cos(Math.toRadians(bearing.toDouble())).toFloat()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val u = min(w, h) / 260f
        canvas.save()
        canvas.translate(w / 2f, h / 2f)
        canvas.scale(u, u)

        val r = 72f
        val orbit = 100f

        canvas.drawCircle(0f, 0f, orbit, orbitPaint)
        for (f in floatArrayOf(1f, 0.75f, 0.5f, 0.25f)) {
            canvas.drawCircle(0f, 0f, r * f, ringPaint)
        }
        for (a in 0 until 360 step 45) {
            canvas.drawLine(0f, 0f, px(r, a.toFloat()), py(r, a.toFloat()), spokePaint)
        }

        canvas.drawText("Vista de cima", -126f, -118f, smallTextPaint)
        canvas.drawText("0 dB", 4f, -r + 11f, smallTextPaint)
        canvas.drawText("-10 dB", 4f, -r * 0.5f + 11f, smallTextPaint)

        val nomes = arrayOf("N", "L", "S", "O")
        for (k in 0..3) {
            val b = k * 90f
            canvas.drawText(nomes[k], px(122f, b), py(122f, b) + 4.5f, if (k == 0) northPaint else textPaint)
        }

        val avg = averages()
        val mx = maxValue(avg)
        val bi = bestIndex(avg)

        path.reset()
        var count = 0
        for (k in 0 until binCount) {
            if (avg[k].isNaN()) continue
            val rel = avg[k] - mx
            val rr = r * max(0.0, (20.0 + rel) / 20.0).toFloat()
            val b = k * binSize + binSize / 2f
            val x = px(rr, b)
            val y = py(rr, b)
            if (count == 0) path.moveTo(x, y) else path.lineTo(x, y)
            count++
        }
        if (count >= 3) {
            path.close()
            canvas.drawPath(path, fillPaint)
            canvas.drawPath(path, strokePaint)
        }
        for (k in 0 until binCount) {
            if (avg[k].isNaN()) continue
            val rel = avg[k] - mx
            val rr = r * max(0.0, (20.0 + rel) / 20.0).toFloat()
            val b = k * binSize + binSize / 2f
            canvas.drawCircle(px(rr, b), py(rr, b), 2.2f, dotPaint)
        }

        if (bi >= 0) {
            val b = bi * binSize + binSize / 2f
            canvas.drawCircle(px(r * 0.96f, b), py(r * 0.96f, b), 5f, bestPaint)
        }

        // posição da pessoa ao redor do roteador: ela olha para o roteador,
        // então o roteador está na direção do celular e a pessoa está do lado oposto
        val pb = (heading + 180f) % 360f

        canvas.drawLine(px(74f, pb), py(74f, pb), px(15f, pb), py(15f, pb), headingPaint)

        // roteador no centro
        rect.set(-8f, -4f, 8f, 4f)
        canvas.drawRoundRect(rect, 2f, 2f, routerFill)
        canvas.drawRoundRect(rect, 2f, 2f, routerStroke)
        canvas.drawLine(-5f, -4f, -7f, -11f, routerStroke)
        canvas.drawLine(5f, -4f, 7f, -11f, routerStroke)

        // avatar na órbita, de frente para o roteador
        val yaw = (12.0 * sin(SystemClock.uptimeMillis() / 700.0)).toFloat()
        canvas.save()
        canvas.translate(px(orbit, pb), py(orbit, pb))
        canvas.rotate(heading)
        canvas.scale(1.1f, 1.1f)
        canvas.drawLine(-10f, -1f, -5f, -14f, armPaint)
        canvas.drawLine(10f, -1f, 5f, -14f, armPaint)
        rect.set(-4f, -23f, 4f, -11f)
        canvas.drawRoundRect(rect, 1.6f, 1.6f, phoneFill)
        canvas.drawRoundRect(rect, 1.6f, 1.6f, phoneStroke)
        rect.set(-13f, -6f, 13f, 6f)
        canvas.drawOval(rect, bodyFill)
        canvas.drawOval(rect, bodyStroke)
        canvas.save()
        canvas.rotate(yaw)
        canvas.drawCircle(0f, 0f, 5.2f, headFill)
        canvas.drawCircle(0f, 0f, 5.2f, headStroke)
        nosePath.reset()
        nosePath.moveTo(-1.8f, -4.6f)
        nosePath.lineTo(1.8f, -4.6f)
        nosePath.lineTo(0f, -8.2f)
        nosePath.close()
        canvas.drawPath(nosePath, nosePaint)
        canvas.restore()
        canvas.restore()

        canvas.restore()
    }
}
