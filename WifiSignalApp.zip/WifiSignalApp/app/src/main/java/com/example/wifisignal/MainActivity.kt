package com.example.wifisignal

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.tabs.TabLayout
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var wifiManager: WifiManager
    private lateinit var sensorManager: SensorManager
    private lateinit var spinnerNetworks: Spinner
    private lateinit var tvSignal: TextView
    private lateinit var tvDistance: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvDirection: TextView
    private lateinit var seekLatency: SeekBar
    private lateinit var tvLatency: TextView
    private lateinit var btnScan: Button
    private lateinit var btnResetCompass: Button
    private lateinit var switchBeep: Switch
    private lateinit var chartSignal: SignalChartView
    private lateinit var compassView: CompassView

    private lateinit var tabLayout: TabLayout
    private lateinit var pageMedidor: View
    private lateinit var pageDiagrama: View
    private lateinit var radiationView: RadiationView
    private lateinit var levelMeter: LevelMeterView
    private lateinit var tvMeterValue: TextView
    private lateinit var tvDiagStatus: TextView
    private lateinit var tvLaps: TextView
    private lateinit var tvSamples: TextView
    private lateinit var tvBest: TextView
    private lateinit var tvBeam: TextView
    private lateinit var btnScanToggle: Button
    private lateinit var btnClearDiag: Button
    private lateinit var btnExport: Button
    private lateinit var btnShare: Button

    private val handler = Handler(Looper.getMainLooper())
    private var latencyMs = 1000L
    private var selectedSsid: String? = null
    private var beepEnabled = true
    private var spinnerList: List<ScanResult> = emptyList()
    private var refreshSpinnerOnResults = false
    private var lastScanRequest = 0L
    private val beepGenerator = BeepGenerator()

    private val rotationMatrix = FloatArray(9)
    private val orientation = FloatArray(3)
    private var currentHeading = 0f

    private var scanning = false
    private var rotationAccum = 0f
    private var lastAz = Float.NaN

    private val MIN_LATENCY = 200
    private val MAX_LATENCY = 5000
    private val STALE_MS = 20000L
    private val SCAN_EVERY_MS = 3000L

    private val requiredPermissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.CHANGE_WIFI_STATE
    )

    private data class Leitura(
        val rssi: Int,
        val freqMhz: Int,
        val aoVivo: Boolean,
        val idadeMs: Long,
        val desatualizado: Boolean
    )

    private val wifiScanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (refreshSpinnerOnResults) {
                refreshSpinnerOnResults = false
                updateSpinner()
            }
        }
    }

    private val monitorRunnable = object : Runnable {
        override fun run() {
            measureAndBeep()
            handler.postDelayed(this, latencyMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        spinnerNetworks = findViewById(R.id.spinnerNetworks)
        tvSignal = findViewById(R.id.tvSignal)
        tvDistance = findViewById(R.id.tvDistance)
        tvStatus = findViewById(R.id.tvStatus)
        tvDirection = findViewById(R.id.tvDirection)
        seekLatency = findViewById(R.id.seekLatency)
        tvLatency = findViewById(R.id.tvLatency)
        btnScan = findViewById(R.id.btnScan)
        btnResetCompass = findViewById(R.id.btnResetCompass)
        switchBeep = findViewById(R.id.switchBeep)
        chartSignal = findViewById(R.id.chartSignal)
        compassView = findViewById(R.id.compassView)

        tabLayout = findViewById(R.id.tabLayout)
        pageMedidor = findViewById(R.id.pageMedidor)
        pageDiagrama = findViewById(R.id.pageDiagrama)
        radiationView = findViewById(R.id.radiationView)
        levelMeter = findViewById(R.id.levelMeter)
        tvMeterValue = findViewById(R.id.tvMeterValue)
        tvDiagStatus = findViewById(R.id.tvDiagStatus)
        tvLaps = findViewById(R.id.tvLaps)
        tvSamples = findViewById(R.id.tvSamples)
        tvBest = findViewById(R.id.tvBest)
        tvBeam = findViewById(R.id.tvBeam)
        btnScanToggle = findViewById(R.id.btnScanToggle)
        btnClearDiag = findViewById(R.id.btnClearDiag)
        btnExport = findViewById(R.id.btnExport)
        btnShare = findViewById(R.id.btnShare)

        tabLayout.addTab(tabLayout.newTab().setText("Medidor"))
        tabLayout.addTab(tabLayout.newTab().setText("Diagrama de radiação"))
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                val diagrama = tab?.position == 1
                pageMedidor.visibility = if (diagrama) View.GONE else View.VISIBLE
                pageDiagrama.visibility = if (diagrama) View.VISIBLE else View.GONE
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        seekLatency.max = MAX_LATENCY - MIN_LATENCY
        seekLatency.progress = (latencyMs - MIN_LATENCY).toInt()
        updateLatencyLabel()

        seekLatency.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                latencyMs = (progress + MIN_LATENCY).toLong()
                updateLatencyLabel()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        switchBeep.setOnCheckedChangeListener { _, isChecked -> beepEnabled = isChecked }

        btnScan.setOnClickListener {
            if (hasAllPermissions()) startScan() else requestPermissions()
        }

        btnResetCompass.setOnClickListener {
            compassView.reset()
            tvDirection.text = "Gire devagar para mapear a direção"
        }

        btnScanToggle.setOnClickListener {
            scanning = !scanning
            lastAz = Float.NaN
            btnScanToggle.text = if (scanning) "Pausar varredura" else "Retomar varredura"
            if (scanning && selectedSsid == null) {
                tvDiagStatus.text = "Escolha uma rede na aba Medidor antes de começar."
            }
        }

        btnClearDiag.setOnClickListener {
            radiationView.reset()
            rotationAccum = 0f
            updateDiagStats()
        }

        btnExport.setOnClickListener { exportCsv(true) }
        btnShare.setOnClickListener { exportCsv(false) }

        spinnerNetworks.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val ssid = spinnerList.getOrNull(position)?.SSID ?: return
                if (ssid != selectedSsid) {
                    selectedSsid = ssid
                    chartSignal.limpar()
                    compassView.reset()
                    radiationView.reset()
                    rotationAccum = 0f
                    updateDiagStats()
                    tvDirection.text = "Gire devagar para mapear a direção"
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        registerReceiver(wifiScanReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))

        if (hasAllPermissions()) {
            startScan()
        } else {
            requestPermissions()
        }
    }

    private fun updateLatencyLabel() {
        tvLatency.text = "Intervalo de medição: $latencyMs ms"
    }

    private fun hasAllPermissions(): Boolean =
        requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(this, requiredPermissions, 100)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && hasAllPermissions()) {
            startScan()
        } else if (requestCode == 100) {
            tvStatus.text = "Permissão de localização é necessária para listar redes Wi-Fi"
        }
    }

    @Suppress("DEPRECATION")
    private fun startScan() {
        tvStatus.text = "Buscando redes..."
        refreshSpinnerOnResults = true
        lastScanRequest = SystemClock.elapsedRealtime()
        val started = wifiManager.startScan()
        if (!started) {
            refreshSpinnerOnResults = false
            updateSpinner()
        }
    }

    @Suppress("DEPRECATION")
    private fun requestScanIfNeeded() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastScanRequest >= SCAN_EVERY_MS) {
            lastScanRequest = now
            wifiManager.startScan()
        }
    }

    @SuppressLint("MissingPermission")
    private fun updateSpinner() {
        spinnerList = wifiManager.scanResults
            .filter { it.SSID.isNotBlank() }
            .groupBy { it.SSID }
            .map { entry -> entry.value.maxByOrNull { it.level }!! }
            .sortedByDescending { it.level }

        val names = spinnerList.map { "${it.SSID}  (${it.level} dBm)" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerNetworks.adapter = adapter

        if (spinnerList.isEmpty()) {
            tvStatus.text = "Nenhuma rede encontrada. Tente novamente."
            return
        }

        val keepIdx = spinnerList.indexOfFirst { it.SSID == selectedSsid }
        if (keepIdx >= 0) {
            spinnerNetworks.setSelection(keepIdx)
        } else {
            selectedSsid = spinnerList[0].SSID
            chartSignal.limpar()
            compassView.reset()
            radiationView.reset()
            rotationAccum = 0f
            updateDiagStats()
        }
        tvStatus.text = "Monitorando: $selectedSsid"
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    private fun lerSinal(ssid: String): Leitura? {
        val info = wifiManager.connectionInfo
        if (info != null && info.networkId != -1) {
            val conectada = info.ssid?.trim('"')
            if (conectada == ssid && info.rssi > -127) {
                return Leitura(info.rssi, info.frequency, true, 0L, false)
            }
        }

        val melhor = wifiManager.scanResults
            .filter { it.SSID == ssid }
            .maxByOrNull { it.level } ?: return null

        val agoraMs = SystemClock.elapsedRealtime()
        val idadeMs = agoraMs - melhor.timestamp / 1000L
        return Leitura(melhor.level, melhor.frequency, false, idadeMs, idadeMs > STALE_MS)
    }

    private fun estimarDistanciaMetros(rssi: Int, freqMhz: Int): Double {
        val rssiA1m = if (freqMhz >= 4900) -47.0 else -40.0
        val n = 3.0
        return 10.0.pow((rssiA1m - rssi) / (10.0 * n))
    }

    private fun formatarDistancia(d: Double): String = when {
        d < 1.0 -> "menos de 1 m"
        d > 50.0 -> "mais de 50 m"
        else -> String.format(Locale.getDefault(), "%.1f m", d)
    }

    private fun mostrarSemSinal(msg: String) {
        tvSignal.text = msg
        tvDistance.text = "Distância estimada: --"
        tvDiagStatus.text = msg
        tvMeterValue.text = "-- dBm"
        levelMeter.setIdle()
    }

    private fun measureAndBeep() {
        if (!wifiManager.isWifiEnabled) {
            mostrarSemSinal("Wi-Fi desligado. Ligue o Wi-Fi para medir.")
            return
        }

        val ssid = selectedSsid
        if (ssid == null) {
            mostrarSemSinal("Escolha uma rede.")
            return
        }

        requestScanIfNeeded()

        val leitura = lerSinal(ssid)
        if (leitura == null) {
            mostrarSemSinal("Rede \"$ssid\" não encontrada. Ela pode ter saído do alcance.")
            return
        }
        if (leitura.desatualizado) {
            mostrarSemSinal(
                "Sinal desatualizado (há ${leitura.idadeMs / 1000} s). A rede pode ter saído do ar."
            )
            return
        }

        @Suppress("DEPRECATION")
        val nivel = WifiManager.calculateSignalLevel(leitura.rssi, 5)
        tvSignal.text = "${leitura.rssi} dBm  (nível ${nivel + 1}/5)"
        tvStatus.text = if (leitura.aoVivo) {
            "Monitorando: $ssid (tempo real)"
        } else {
            "Monitorando: $ssid (varredura)"
        }

        val dist = estimarDistanciaMetros(leitura.rssi, leitura.freqMhz)
        tvDistance.text = "Distância estimada: ${formatarDistancia(dist)}"

        chartSignal.addValue(leitura.rssi)
        compassView.addSample(currentHeading, leitura.rssi)
        atualizarTextoDirecao()

        levelMeter.setRssi(leitura.rssi)
        tvMeterValue.text = "${leitura.rssi} dBm"
        tvDiagStatus.text = if (scanning) {
            "Varredura em andamento em $ssid. Ande devagar ao redor do roteador."
        } else {
            "$ssid: toque em Iniciar varredura e dê voltas ao redor do roteador, de frente para ele."
        }
        if (scanning) {
            radiationView.addSample((currentHeading + 180f) % 360f, leitura.rssi)
        }
        updateDiagStats()

        if (beepEnabled) {
            beepGenerator.beepForRssi(leitura.rssi)
        }
    }

    private fun nomeCardeal(graus: Float): String {
        val nomes = arrayOf("N", "NE", "L", "SE", "S", "SO", "O", "NO")
        val idx = (((graus + 22.5f) % 360f) / 45f).toInt() % 8
        return nomes[idx]
    }

    private fun atualizarTextoDirecao() {
        val melhor = compassView.bestBearing()
        if (melhor == null) {
            tvDirection.text = "Gire devagar para mapear a direção"
        } else {
            val pct = (compassView.coverage() * 100).toInt()
            tvDirection.text =
                "Maior sinal: ${nomeCardeal(melhor)} (${melhor.toInt()}°), mapeado $pct%"
        }
    }

    private fun updateDiagStats() {
        val voltas = abs(rotationAccum) / 360f
        tvLaps.text = String.format(Locale.getDefault(), "%.1f", voltas)
        tvSamples.text = radiationView.sampleCount.toString()
        val melhor = radiationView.bestBearing()
        if (melhor == null) {
            tvBest.text = "--"
            tvBeam.text = "--"
        } else {
            tvBest.text = "${nomeCardeal(melhor)} ${melhor.toInt()}°"
            tvBeam.text = "${radiationView.beamwidthDeg()}°"
        }
    }

    private fun exportCsv(direitoNoWhatsApp: Boolean) {
        if (radiationView.sampleCount == 0) {
            Toast.makeText(this, "Sem dados para exportar. Faça uma varredura primeiro.", Toast.LENGTH_LONG).show()
            return
        }

        val ssid = selectedSsid ?: "rede"
        val csv = radiationView.toCsv(ssid)
        val seguro = ssid.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val carimbo = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val pasta = File(cacheDir, "exports").apply { mkdirs() }
        val arquivo = File(pasta, "diagrama_radiacao_${seguro}_$carimbo.csv")
        arquivo.writeText(csv, Charsets.UTF_8)

        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", arquivo)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Diagrama de radiação Wi-Fi: $ssid")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        if (direitoNoWhatsApp) {
            for (pacote in arrayOf("com.whatsapp", "com.whatsapp.w4b")) {
                intent.setPackage(pacote)
                try {
                    startActivity(intent)
                    return
                } catch (_: ActivityNotFoundException) {
                }
            }
            intent.setPackage(null)
            Toast.makeText(this, "WhatsApp não encontrado. Abrindo outras opções.", Toast.LENGTH_LONG).show()
        }
        startActivity(Intent.createChooser(intent, "Enviar CSV"))
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        try {
            val valores = if (event.values.size > 4) event.values.copyOf(4) else event.values
            SensorManager.getRotationMatrixFromVector(rotationMatrix, valores)
            SensorManager.getOrientation(rotationMatrix, orientation)
            var az = Math.toDegrees(orientation[0].toDouble()).toFloat()
            if (az < 0f) az += 360f

            if (scanning && !lastAz.isNaN()) {
                var d = az - lastAz
                if (d > 180f) d -= 360f else if (d < -180f) d += 360f
                if (abs(d) < 30f) rotationAccum += d
            }
            lastAz = az

            val delta = ((az - currentHeading + 540f) % 360f) - 180f
            currentHeading = (currentHeading + delta * 0.25f + 360f) % 360f
            compassView.setHeading(currentHeading)
            radiationView.setHeading(currentHeading)
        } catch (_: Exception) {
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onResume() {
        super.onResume()
        val rotacao = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotacao != null) {
            sensorManager.registerListener(this, rotacao, SensorManager.SENSOR_DELAY_GAME)
        } else {
            tvDirection.text = "Este celular não tem sensor de rotação para a bússola."
        }
        handler.post(monitorRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(monitorRunnable)
        sensorManager.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(wifiScanReceiver)
    }
}
