package com.example.wifisignal

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var wifiManager: WifiManager
    private lateinit var spinnerNetworks: Spinner
    private lateinit var tvSignal: TextView
    private lateinit var tvStatus: TextView
    private lateinit var seekLatency: SeekBar
    private lateinit var tvLatency: TextView
    private lateinit var btnScan: Button
    private lateinit var switchBeep: Switch

    private val handler = Handler(Looper.getMainLooper())
    private var latencyMs = 1000L
    private var selectedSsid: String? = null
    private var beepEnabled = true
    private var scanResultsList: List<ScanResult> = emptyList()
    private val beepGenerator = BeepGenerator()

    // Intervalo permitido: 200 ms (rápido) até 5000 ms (lento)
    private val MIN_LATENCY = 200
    private val MAX_LATENCY = 5000

    private val requiredPermissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.CHANGE_WIFI_STATE
    )

    private val wifiScanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateScanResults()
        }
    }

    private val monitorRunnable = object : Runnable {
        override fun run() {
            measureAndBeep()
            handler.postDelayed(this, latencyMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        spinnerNetworks = findViewById(R.id.spinnerNetworks)
        tvSignal = findViewById(R.id.tvSignal)
        tvStatus = findViewById(R.id.tvStatus)
        seekLatency = findViewById(R.id.seekLatency)
        tvLatency = findViewById(R.id.tvLatency)
        btnScan = findViewById(R.id.btnScan)
        switchBeep = findViewById(R.id.switchBeep)

        seekLatency.max = MAX_LATENCY - MIN_LATENCY
        seekLatency.progress = (latencyMs - MIN_LATENCY).toInt()
        updateLatencyLabel()

        seekLatency.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                latencyMs = (progress + MIN_LATENCY).toLong()
                updateLatencyLabel()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        switchBeep.setOnCheckedChangeListener { _, isChecked -> beepEnabled = isChecked }

        btnScan.setOnClickListener {
            if (hasAllPermissions()) startScan() else requestPermissions()
        }

        spinnerNetworks.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (position in scanResultsList.indices) {
                    selectedSsid = scanResultsList[position].SSID
                    tvStatus.text = "Monitorando: $selectedSsid"
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        registerReceiver(wifiScanReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))

        if (hasAllPermissions()) {
            startScan()
        } else {
            requestPermissions()
        }
    }

    private fun updateLatencyLabel() {
        tvLatency.text = "Intervalo de medição: $latencyMs ms"
    }

    private fun hasAllPermissions(): Boolean =
        requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(this, requiredPermissions, 100)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && hasAllPermissions()) {
            startScan()
        } else if (requestCode == 100) {
            tvStatus.text = "Permissão de localização é necessária para listar redes Wi-Fi"
        }
    }

    @Suppress("DEPRECATION")
    private fun startScan() {
        tvStatus.text = "Buscando redes..."
        val started = wifiManager.startScan()
        if (!started) {
            updateScanResults()
        }
    }

    @Suppress("MissingPermission")
    private fun updateScanResults() {
        scanResultsList = wifiManager.scanResults
            .filter { it.SSID.isNotBlank() }
            .distinctBy { it.SSID }
            .sortedByDescending { it.level }

        val names = scanResultsList.map { "${it.SSID}  (${it.level} dBm)" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerNetworks.adapter = adapter

        if (scanResultsList.isNotEmpty()) {
            selectedSsid = scanResultsList[0].SSID
            tvStatus.text = "Monitorando: $selectedSsid"
        } else {
            tvStatus.text = "Nenhuma rede encontrada. Tente novamente."
        }
    }

    @Suppress("MissingPermission")
    private fun measureAndBeep() {
        val ssid = selectedSsid ?: return
        val result = scanResultsList.find { it.SSID == ssid }
            ?: wifiManager.scanResults.find { it.SSID == ssid }

        if (result != null) {
            val rssi = result.level
            val quality = WifiManager.calculateSignalLevel(rssi, 5) // 0..4
            tvSignal.text = "$ssid: $rssi dBm  (nível ${quality + 1}/5)"
            if (beepEnabled) {
                beepGenerator.beepForRssi(rssi)
            }
        } else {
            tvSignal.text = "Sinal não encontrado. Toque em \"Buscar redes\"."
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(monitorRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(monitorRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(wifiScanReceiver)
    }
}
