# Medidor de Sinal Wi-Fi (Android)

App Android nativo que:
- Escaneia e lista as redes Wi-Fi próximas.
- Permite escolher qual rede monitorar.
- Mostra a força do sinal em dBm e em nível (1 a 5).
- Toca um "beep" cujo tom varia com a força do sinal (agudo = sinal forte, grave = sinal fraco).
- Permite ajustar o intervalo (latência) entre cada medição, de 200 ms a 5000 ms, usando o controle deslizante.

## Como abrir e rodar

1. Instale o [Android Studio](https://developer.android.com/studio) (gratuito).
2. Abra o Android Studio → **Open** → selecione a pasta `WifiSignalApp`.
3. Aguarde o Gradle sincronizar (baixa as dependências automaticamente).
4. Conecte um celular Android via USB (com "Depuração USB" ativada) ou use um emulador.
5. Clique em **Run ▶**.

## Permissões

Na primeira execução, o app vai pedir permissão de **Localização**. Isso é uma exigência do próprio Android (não é capricho do app): desde o Android 6, listar redes Wi-Fi próximas exige essa permissão, pois a lista de redes pode revelar a localização do usuário. Sem aceitar, o app não consegue enxergar as redes.

## Limitações importantes

- **Throttling de scan**: a partir do Android 9, o sistema limita quantas vezes por período um app pode pedir um novo scan de redes (geralmente poucas vezes a cada 2 minutos). Por isso o app reaproveita o último resultado de scan entre as medições, e só um novo `startScan()` (botão "Buscar redes") atualiza a lista de fato.
- **Rede não encontrada**: se a rede escolhida sair de alcance ou o scan não for atualizado, o app avisa na tela "Sinal não encontrado".
- **Sinal apenas de redes visíveis**: o app lê o RSSI (força de sinal) reportado pelo próprio chip Wi-Fi do celular, exatamente como aparece nas configurações de Wi-Fi do Android — a mesma limitação de qualquer app desse tipo.

## Personalizações fáceis

- **Faixa do intervalo**: altere `MIN_LATENCY` e `MAX_LATENCY` em `MainActivity.kt`.
- **Faixa de frequência do beep**: altere os valores `300.0` (grave) e `2000.0` (agudo) em `BeepGenerator.kt`.
- **Beep diferente**: em vez de tom por frequência, você pode trocar a lógica para "bipes mais rápidos = sinal mais forte" (estilo detector de metal), repetindo o beep dentro do próprio intervalo de medição.
