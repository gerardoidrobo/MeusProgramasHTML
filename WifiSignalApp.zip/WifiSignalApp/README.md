# Medidor de Sinal Wi-Fi (Android)

App com duas abas.

## Aba Medidor
- Escaneia as redes Wi-Fi, você escolhe qual monitorar.
- Mostra o sinal em dBm, nível (1 a 5), distância estimada e gráfico de intensidade.
- Beep cujo tom varia com a força do sinal (agudo = forte, grave = fraco).
- Intervalo entre medições ajustável de 200 ms a 5000 ms.
- Bússola de sinal simples (seta para a direção de maior sinal).
- Para de apitar com o Wi-Fi desligado ou quando a rede some.

## Aba Diagrama de radiação
- Gráfico polar em dB (0 dB na borda), visto de cima, com o roteador no centro e um avatar que anda na órbita ao redor dele.
- O ângulo de cada medida é a posição da pessoa em relação ao roteador (direção do celular + 180°, porque a pessoa olha para o roteador).
- Coluna de força no estilo de medidor de volume, com marca de pico.
- Média por setor de 10 graus, calculada em potência (mW); várias voltas melhoram o resultado.
- Estatísticas: voltas, amostras, direção de maior sinal e largura do feixe em -3 dB.
- Enviar CSV pelo WhatsApp: gera um arquivo .csv (ângulo, potência média, relativo ao máximo, amostras) e abre o WhatsApp para você escolher o contato. Também há um botão para compartilhar em outros apps (e-mail, Drive etc.).

### Como medir
1. Na aba Medidor, escolha a rede.
2. Na aba Diagrama de radiação, toque em Iniciar varredura.
3. Ande em volta do roteador, sempre de frente para ele, com o celular na horizontal à sua frente. Mantenha a mesma distância (1 a 2 m; um barbante esticado ajuda). De 3 a 5 voltas, cada uma em 60 a 90 s.
4. A bússola da aba Medidor serve para achar a direção do roteador girando no lugar.

## Limites
- O Android atualiza o sinal da rede conectada a cada cerca de 1 s; para as outras redes depende da varredura do sistema, que é limitada.
- RSSI não é calibrado: serve para comparar formas e valores relativos, não para medir ganho absoluto.
- A distância é uma estimativa grosseira.
- O Android exige permissão de Localização para listar redes Wi-Fi.
- Ao instalar por cima de uma versão anterior, o Android pode recusar (assinatura diferente). Desinstale a antiga antes.
