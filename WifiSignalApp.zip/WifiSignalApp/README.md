# Medidor de Sinal Wi-Fi (Android)

App Android nativo que:
- Escaneia e lista as redes Wi-Fi próximas e deixa você escolher qual monitorar.
- Mostra a força do sinal em dBm e em nível (1 a 5), com gráfico de intensidade.
- Toca um beep cujo tom varia com a força do sinal (agudo = forte, grave = fraco).
- Permite ajustar o intervalo entre medições, de 200 ms a 5000 ms.
- Para de apitar quando o Wi-Fi está desligado ou a rede some.
- Mostra uma distância estimada e uma bússola que aponta para a direção de maior sinal.

## Como compilar

Pelo GitHub Actions (workflow em .github/workflows/build.yml) ou abrindo esta pasta no Android Studio.

## Observações

- O Android exige permissão de Localização para listar redes Wi-Fi.
- Para a rede conectada o sinal é lido ao vivo. Para as outras, depende da varredura do Android, que é limitada.
- A distância é uma estimativa grosseira (paredes e móveis mudam o resultado).
- Na bússola, segure o celular na horizontal, longe do corpo, e gire devagar.
- Ao instalar por cima de uma versão anterior, o Android pode recusar (assinatura diferente). Desinstale a antiga antes.
